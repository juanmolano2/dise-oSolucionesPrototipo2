using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using GraphQL;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.SystemTextJson;
using EnvioCliente.model;

namespace EnvioCliente
{
    public partial class GUIAdicionarEnvioNacional : Form
    {
        public GUIAdicionarEnvioNacional()
        {
            InitializeComponent();
        }

        private async void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPrecio.Text, out double precio))
            {
                MessageBox.Show("El precio debe ser numerico.");
                return;
            }

            if (!int.TryParse(txtCodigoPostalNacional.Text, out int codigoPostal))
            {
                MessageBox.Show("El codigo postal debe ser un numero entero.");
                return;
            }

            if (!DateTime.TryParseExact(txtFechaSalida.Text, "dd/MM/yyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out DateTime fechaSalida))
            {
                MessageBox.Show("La fecha debe tener el formato dd/MM/yyyy, ejemplo 04/05/2023.");
                return;
            }

            await adicionarEnvioNacional(precio, codigoPostal, fechaSalida);
        }

        private async Task adicionarEnvioNacional(double precio, int codigoPostal, DateTime fechaSalida)
        {
            var client = new GraphQLHttpClient(
                "http://localhost:8081/graphql",
                new SystemTextJsonSerializer());

            var inputData = new EnvioNacionalInput
            {
                codigo = txtCodigo.Text,
                origen = txtOrigen.Text,
                destino = txtDestino.Text,
                precio = precio,
                fechaSalida = fechaSalida.ToString("yyyy-MM-ddTHH:mm:ss"),
                departamentoDestino = txtDepartamentoDestino.Text,
                codigoPostalNacional = codigoPostal
            };

            var request = new GraphQLRequest
            {
                Query = @"
                    mutation addEnvioNacional($input: EnvioNacionalInput!) {
                        addEnvioNacional(input: $input) {
                            codigo
                            origen
                            destino
                        }
                    }
                ",
                Variables = new
                {
                    input = inputData
                }
            };

            var response = await client.SendMutationAsync<AddEnvioNacionalResponse>(request);

            if (response.Errors != null && response.Errors.Length > 0)
            {
                MessageBox.Show(response.Errors[0].Message);
            }
            else if (response.Data.AddEnvioNacional == null)
            {
                MessageBox.Show("Ya existe un envio con ese codigo.");
            }
            else
            {
                MessageBox.Show("Envio adicionado correctamente.");
                Close();
            }
        }
    }
}
