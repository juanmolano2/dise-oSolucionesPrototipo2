using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using GraphQL;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.SystemTextJson;
using EnvioCliente.model;

namespace EnvioCliente
{
    public partial class GUIListarEnvioNacional : Form
    {
        public GUIListarEnvioNacional()
        {
            InitializeComponent();
        }

        private async void btnListarTodos_Click(object sender, EventArgs e)
        {
            await listarTodos();
        }

        private async void btnFiltrar_Click(object sender, EventArgs e)
        {
            await filtrarEnvios();
        }

        private async Task listarTodos()
        {
            var client = new GraphQLHttpClient(
                "http://localhost:8081/graphql",
                new SystemTextJsonSerializer());

            var request = new GraphQLRequest
            {
                Query = @"
                    query enviosNacionales {
                        enviosNacionales {
                            codigo
                            origen
                            destino
                            precio
                            fechaSalida
                            departamentoDestino
                            codigoPostalNacional
                        }
                    }
                "
            };

            var response = await client.SendQueryAsync<ResponseListaEnvios>(request);
            mostrarResultado(response.Errors, response.Data?.envios);
        }

        private async Task filtrarEnvios()
        {
            var client = new GraphQLHttpClient(
                "http://localhost:8081/graphql",
                new SystemTextJsonSerializer());

            var request = new GraphQLRequest
            {
                Query = @"
                    query enviosNacionalesFiltrados($origen: String, $departamentoDestino: String) {
                        enviosNacionalesFiltrados(origen: $origen, departamentoDestino: $departamentoDestino) {
                            codigo
                            origen
                            destino
                            precio
                            fechaSalida
                            departamentoDestino
                            codigoPostalNacional
                        }
                    }
                ",
                Variables = new
                {
                    origen = txtOrigen.Text,
                    departamentoDestino = txtDepartamentoDestino.Text
                }
            };

            var response = await client.SendQueryAsync<ResponseEnviosFiltrados>(request);
            mostrarResultado(response.Errors, response.Data?.envios);
        }

        private void mostrarResultado(GraphQL.GraphQLError[] errores, EnvioNacionalData[] envios)
        {
            if (errores != null && errores.Length > 0)
            {
                MessageBox.Show(errores[0].Message);
                return;
            }

            dgvEnvios.DataSource = envios;
        }
    }
}
