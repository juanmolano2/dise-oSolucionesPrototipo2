using System.Text.Json.Serialization;

namespace EnvioCliente.model
{
    public class EnvioNacionalData
    {
        [JsonPropertyName("codigo")]
        public string codigo { get; set; }

        [JsonPropertyName("origen")]
        public string origen { get; set; }

        [JsonPropertyName("destino")]
        public string destino { get; set; }

        [JsonPropertyName("precio")]
        public double precio { get; set; }

        [JsonPropertyName("fechaSalida")]
        public string fechaSalida { get; set; }

        [JsonPropertyName("departamentoDestino")]
        public string departamentoDestino { get; set; }

        [JsonPropertyName("codigoPostalNacional")]
        public int codigoPostalNacional { get; set; }
    }

    public class EnvioNacionalInput
    {
        [JsonPropertyName("codigo")]
        public string codigo { get; set; }

        [JsonPropertyName("origen")]
        public string origen { get; set; }

        [JsonPropertyName("destino")]
        public string destino { get; set; }

        [JsonPropertyName("precio")]
        public double precio { get; set; }

        [JsonPropertyName("fechaSalida")]
        public string fechaSalida { get; set; }

        [JsonPropertyName("departamentoDestino")]
        public string departamentoDestino { get; set; }

        [JsonPropertyName("codigoPostalNacional")]
        public int codigoPostalNacional { get; set; }
    }

    public class ResponseEnvioNacional
    {
        [JsonPropertyName("envioNacionalPorCodigo")]
        public EnvioNacionalData envio { get; set; }
    }

    public class ResponseListaEnvios
    {
        [JsonPropertyName("enviosNacionales")]
        public EnvioNacionalData[] envios { get; set; }
    }

    public class ResponseEnviosFiltrados
    {
        [JsonPropertyName("enviosNacionalesFiltrados")]
        public EnvioNacionalData[] envios { get; set; }
    }

    public class AddEnvioNacionalResponse
    {
        [JsonPropertyName("addEnvioNacional")]
        public EnvioNacionalData AddEnvioNacional { get; set; }
    }

    public class UpdateEnvioNacionalResponse
    {
        [JsonPropertyName("updateEnvioNacional")]
        public EnvioNacionalData UpdateEnvioNacional { get; set; }
    }

    public class DeleteEnvioNacionalResponse
    {
        [JsonPropertyName("deleteEnvioNacional")]
        public EnvioNacionalData DeleteEnvioNacional { get; set; }
    }
}
