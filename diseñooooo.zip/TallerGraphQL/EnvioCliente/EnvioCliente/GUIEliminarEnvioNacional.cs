using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using GraphQL;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.SystemTextJson;
using EnvioCliente.model;

namespace EnvioCliente
{
    public partial class GUIEliminarEnvioNacional : Form
    {
        public GUIEliminarEnvioNacional()
        {
            InitializeComponent();
        }

        private async void btnBuscar_Click(object sender, EventArgs e)
        {
            await buscarEnvioNacional();
        }

        private async void btnEliminar_Click(object sender, EventArgs e)
        {
            await eliminarEnvioNacional();
        }

        private async Task buscarEnvioNacional()
        {
            var client = new GraphQLHttpClient(
                "http://localhost:8081/graphql",
                new SystemTextJsonSerializer());

            var request = new GraphQLRequest
            {
                Query = @"
                    query envioNacionalPorCodigo($codigo: String!) {
                        envioNacionalPorCodigo(codigo: $codigo) {
                            codigo
                            origen
                            destino
                            precio
                            fechaSalida
                            departamentoDestino
                            codigoPostalNacional
                        }
                    }
                ",
                Variables = new
                {
                    codigo = txtCodigo.Text
                }
            };

            var response = await client.SendQueryAsync<ResponseEnvioNacional>(request);

            if (response.Errors != null && response.Errors.Length > 0)
            {
                MessageBox.Show(response.Errors[0].Message);
                return;
            }

            var envio = response.Data.envio;

            if (envio == null)
            {
                MessageBox.Show("No existe un envio con ese codigo.");
                btnEliminar.Enabled = false;
                return;
            }

            txtOrigen.Text = envio.origen;
            txtDestino.Text = envio.destino;
            txtPrecio.Text = envio.precio.ToString();
            txtFechaSalida.Text = DateTime.Parse(envio.fechaSalida).ToString("dd/MM/yyyy");
            txtDepartamentoDestino.Text = envio.departamentoDestino;
            txtCodigoPostalNacional.Text = envio.codigoPostalNacional.ToString();

            btnEliminar.Enabled = true;
        }

        private async Task eliminarEnvioNacional()
        {
            var client = new GraphQLHttpClient(
                "http://localhost:8081/graphql",
                new SystemTextJsonSerializer());

            var request = new GraphQLRequest
            {
                Query = @"
                    mutation deleteEnvioNacional($codigo: String!) {
                        deleteEnvioNacional(codigo: $codigo) {
                            codigo
                        }
                    }
                ",
                Variables = new
                {
                    codigo = txtCodigo.Text
                }
            };

            var response = await client.SendMutationAsync<DeleteEnvioNacionalResponse>(request);

            if (response.Errors != null && response.Errors.Length > 0)
            {
                MessageBox.Show(response.Errors[0].Message);
            }
            else
            {
                MessageBox.Show("Envio eliminado correctamente.");
                Close();
            }
        }
    }
}
