using System;
using System.Windows.Forms;

namespace EnvioCliente
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void adicionarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new GUIAdicionarEnvioNacional().ShowDialog();
        }

        private void consultarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new GUIConsultarEnvioNacional().ShowDialog();
        }

        private void listarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new GUIListarEnvioNacional().ShowDialog();
        }

        private void actualizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new GUIActualizarEnvioNacional().ShowDialog();
        }

        private void eliminarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new GUIEliminarEnvioNacional().ShowDialog();
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Gestión de Envíos Nacionales\nVersión 1.0\n\nIntegrantes:\n" +
                "Juan Esteban Molano Polanco codigo 2220232008\n" +
                "Juan Pablo Chacon codigo 2220232030\n" +
                "Johan Daniel Esterling codigo 2220241033",
                "Acerca de...");
        }
    }
}
