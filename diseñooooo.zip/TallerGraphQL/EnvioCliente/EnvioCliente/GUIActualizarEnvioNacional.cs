using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using GraphQL;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.SystemTextJson;
using EnvioCliente.model;

namespace EnvioCliente
{
    public partial class GUIActualizarEnvioNacional : Form
    {
        public GUIActualizarEnvioNacional()
        {
            InitializeComponent();
        }

        private async void btnBuscar_Click(object sender, EventArgs e)
        {
            await buscarEnvioNacional();
        }

        private async void btnActualizar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPrecio.Text, out double precio))
            {
                MessageBox.Show("El precio debe ser numerico.");
                return;
            }

            if (!int.TryParse(txtCodigoPostalNacional.Text, out int codigoPostal))
            {
                MessageBox.Show("El codigo postal debe ser un numero entero.");
                return;
            }

            if (!DateTime.TryParseExact(txtFechaSalida.Text, "dd/MM/yyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out DateTime fechaSalida))
            {
                MessageBox.Show("La fecha debe tener el formato dd/MM/yyyy, ejemplo 04/05/2023.");
                return;
            }

            await actualizarEnvioNacional(precio, codigoPostal, fechaSalida);
        }

        private async Task buscarEnvioNacional()
        {
            var client = new GraphQLHttpClient(
                "http://localhost:8081/graphql",
                new SystemTextJsonSerializer());

            var request = new GraphQLRequest
            {
                Query = @"
                    query envioNacionalPorCodigo($codigo: String!) {
                        envioNacionalPorCodigo(codigo: $codigo) {
                            codigo
                            origen
                            destino
                            precio
                            fechaSalida
                            departamentoDestino
                            codigoPostalNacional
                        }
                    }
                ",
                Variables = new
                {
                    codigo = txtCodigo.Text
                }
            };

            var response = await client.SendQueryAsync<ResponseEnvioNacional>(request);

            if (response.Errors != null && response.Errors.Length > 0)
            {
                MessageBox.Show(response.Errors[0].Message);
                return;
            }

            var envio = response.Data.envio;

            if (envio == null)
            {
                MessageBox.Show("No existe un envio con ese codigo.");
                habilitarCampos(false);
                return;
            }

            txtOrigen.Text = envio.origen;
            txtDestino.Text = envio.destino;
            txtPrecio.Text = envio.precio.ToString();
            txtFechaSalida.Text = DateTime.Parse(envio.fechaSalida).ToString("dd/MM/yyyy");
            txtDepartamentoDestino.Text = envio.departamentoDestino;
            txtCodigoPostalNacional.Text = envio.codigoPostalNacional.ToString();

            habilitarCampos(true);
        }

        private async Task actualizarEnvioNacional(double precio, int codigoPostal, DateTime fechaSalida)
        {
            var client = new GraphQLHttpClient(
                "http://localhost:8081/graphql",
                new SystemTextJsonSerializer());

            var inputData = new EnvioNacionalInput
            {
                codigo = txtCodigo.Text,
                origen = txtOrigen.Text,
                destino = txtDestino.Text,
                precio = precio,
                fechaSalida = fechaSalida.ToString("yyyy-MM-ddTHH:mm:ss"),
                departamentoDestino = txtDepartamentoDestino.Text,
                codigoPostalNacional = codigoPostal
            };

            var request = new GraphQLRequest
            {
                Query = @"
                    mutation updateEnvioNacional($input: EnvioNacionalInput!) {
                        updateEnvioNacional(input: $input) {
                            codigo
                        }
                    }
                ",
                Variables = new
                {
                    input = inputData
                }
            };

            var response = await client.SendMutationAsync<UpdateEnvioNacionalResponse>(request);

            if (response.Errors != null && response.Errors.Length > 0)
            {
                MessageBox.Show(response.Errors[0].Message);
            }
            else
            {
                MessageBox.Show("Envio actualizado correctamente.");
                Close();
            }
        }

        private void habilitarCampos(bool habilitar)
        {
            txtOrigen.Enabled = habilitar;
            txtDestino.Enabled = habilitar;
            txtPrecio.Enabled = habilitar;
            txtFechaSalida.Enabled = habilitar;
            txtDepartamentoDestino.Enabled = habilitar;
            txtCodigoPostalNacional.Enabled = habilitar;
            btnActualizar.Enabled = habilitar;
        }
    }
}
