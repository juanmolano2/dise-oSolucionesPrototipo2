package com.example.envio.model;

public record EnvioNacionalInput(String codigo, String origen, String destino, double precio,
                                 String fechaSalida, String departamentoDestino, int codigoPostalNacional) {
}
