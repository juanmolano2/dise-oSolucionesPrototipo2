package com.example.envio.servicios;

import com.example.envio.model.EnvioNacional;
import com.example.envio.model.EnvioNacionalInput;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ServicioEnvioNacional {
    private static List<EnvioNacional> envios = new ArrayList<>();

    public static List<EnvioNacional> listarEnvios() {
        return envios;
    }

    public static List<EnvioNacional> filtrarEnvios(String origen, String departamentoDestino) {
        return envios.stream()
                .filter(e -> origen == null || origen.isBlank() || e.getOrigen().equalsIgnoreCase(origen))
                .filter(e -> departamentoDestino == null || departamentoDestino.isBlank()
                        || e.getDepartamentoDestino().equalsIgnoreCase(departamentoDestino))
                .toList();
    }

    public static Optional<EnvioNacional> buscarPorCodigo(String codigo) {
        return envios.stream()
                .filter(e -> e.getCodigo().equalsIgnoreCase(codigo))
                .findFirst();
    }

    public static Optional<EnvioNacional> addEnvio(EnvioNacionalInput input) {
        if (buscarPorCodigo(input.codigo()).isPresent()) {
            return Optional.empty();
        }
        EnvioNacional envio = new EnvioNacional(input.codigo(), input.origen(), input.destino(), input.precio(),
                LocalDateTime.parse(input.fechaSalida()), input.departamentoDestino(), input.codigoPostalNacional());
        envios.add(envio);

        return Optional.of(envio);
    }

    public static Optional<EnvioNacional> updateEnvio(EnvioNacionalInput input) {
        Optional<EnvioNacional> envio = buscarPorCodigo(input.codigo());
        envio.ifPresent(e -> {
            e.setOrigen(input.origen());
            e.setDestino(input.destino());
            e.setPrecio(input.precio());
            e.setFechaSalida(LocalDateTime.parse(input.fechaSalida()));
            e.setDepartamentoDestino(input.departamentoDestino());
            e.setCodigoPostalNacional(input.codigoPostalNacional());
        });

        return envio;
    }

    public static Optional<EnvioNacional> deleteEnvio(String codigo) {
        Optional<EnvioNacional> envio = buscarPorCodigo(codigo);
        envio.ifPresent(envios::remove);

        return envio;
    }

}
