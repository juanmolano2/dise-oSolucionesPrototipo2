package com.example.envio.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class EnvioNacional extends Envio {
    private String departamentoDestino;
    private int codigoPostalNacional;

    public EnvioNacional(String codigo, String origen, String destino, double precio,
                         LocalDateTime fechaSalida, String departamentoDestino, int codigoPostalNacional) {
        super(codigo, origen, destino, precio, fechaSalida);
        this.departamentoDestino = departamentoDestino;
        this.codigoPostalNacional = codigoPostalNacional;
    }
}
