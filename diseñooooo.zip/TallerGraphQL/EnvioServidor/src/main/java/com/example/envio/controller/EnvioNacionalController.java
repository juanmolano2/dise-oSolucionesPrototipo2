package com.example.envio.controller;

import com.example.envio.model.EnvioNacional;
import com.example.envio.model.EnvioNacionalInput;
import com.example.envio.servicios.ServicioEnvioNacional;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class EnvioNacionalController {

    @QueryMapping
    public List<EnvioNacional> enviosNacionales() {
        return ServicioEnvioNacional.listarEnvios();
    }

    @QueryMapping
    public List<EnvioNacional> enviosNacionalesFiltrados(@Argument String origen, @Argument String departamentoDestino) {
        return ServicioEnvioNacional.filtrarEnvios(origen, departamentoDestino);
    }

    @QueryMapping
    public Optional<EnvioNacional> envioNacionalPorCodigo(@Argument String codigo) {
        return ServicioEnvioNacional.buscarPorCodigo(codigo);
    }

    @MutationMapping
    public Optional<EnvioNacional> addEnvioNacional(@Argument("input") EnvioNacionalInput input) {
        return ServicioEnvioNacional.addEnvio(input);
    }

    @MutationMapping
    public Optional<EnvioNacional> updateEnvioNacional(@Argument("input") EnvioNacionalInput input) {
        return ServicioEnvioNacional.updateEnvio(input);
    }

    @MutationMapping
    public Optional<EnvioNacional> deleteEnvioNacional(@Argument String codigo) {
        return ServicioEnvioNacional.deleteEnvio(codigo);
    }

}
