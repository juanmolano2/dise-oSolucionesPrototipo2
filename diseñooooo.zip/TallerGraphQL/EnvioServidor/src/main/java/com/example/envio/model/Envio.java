package com.example.envio.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Envio {
    private String codigo;
    private String origen;
    private String destino;
    private double precio;
    private LocalDateTime fechaSalida;
}
